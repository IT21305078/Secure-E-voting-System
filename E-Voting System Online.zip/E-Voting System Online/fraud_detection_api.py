from flask import Flask, request, jsonify
import pickle
import pandas as pd

app = Flask(__name__)


try:
    with open('C:/xampp/htdocs/E-Voting System Online/fraud_detection_model.pkl', 'rb') as model_file:
        model = pickle.load(model_file)
    with open('C:/xampp/htdocs/E-Voting System Online/scaler.pkl', 'rb') as scaler_file:
        scaler = pickle.load(scaler_file)
except Exception as e:
    print(f"Error loading model or scaler: {e}")

feature_names = ['ct_src_dport_ltm', 'ct_dst_sport_ltm', 'sbytes', 'dbytes', 'spkts', 'dpkts', 'rate']

@app.route('/detect_fraud', methods=['POST'])
def detect_fraud():
    try:
        data = request.json
        print(f"Received data: {data}")
        
        df = pd.DataFrame([data])
        features = df[feature_names]
        features_scaled = scaler.transform(features)
        
        prediction = model.predict(features_scaled)
        
    
        result = 'fraud' if prediction[0] == -1 else 'normal'
        
        print(f"Prediction: {prediction[0]}, Result: {result}")
        
        return jsonify({'result': result})
    except Exception as e:
        print(f"Error processing request: {e}")
        return jsonify({'error': f'An error occurred during processing: {e}'}), 500

if __name__ == '__main__':
    app.run(debug=True)
