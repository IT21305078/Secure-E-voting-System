<?php
session_start();

include("../api/connect.php");



if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die("Invalid CSRF token");
    }

   
    
    $fullName = htmlspecialchars(trim($_POST['fullName']));
    $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
    $phone = htmlspecialchars(trim($_POST['phone']));
    $officeId = htmlspecialchars(trim($_POST['officeId']));
    $sex = htmlspecialchars(trim($_POST['sex']));
    $department = htmlspecialchars(trim($_POST['department']));
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];
    $verificationPicTmpName = $_FILES['verificationPic']['tmp_name'];

    if ($password !== $confirmPassword) {
        die("Error: Passwords do not match");
    }

   
    
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    
    
    $encryptionKey = generateRandomString(16);

   
    
    $encryptedEmail = openssl_encrypt($email, 'aes-256-cbc', $encryptionKey, 0, $encryptionKey);
    $encryptedPhone = openssl_encrypt($phone, 'aes-256-cbc', $encryptionKey, 0, $encryptionKey);

    
    $verificationPicContent = file_get_contents($verificationPicTmpName);
    $encryptedVerificationPic = openssl_encrypt($verificationPicContent, 'aes-256-cbc', $encryptionKey, 0, $encryptionKey);

    
    $verificationPicHash = hash('sha256', $verificationPicContent);

   
    $sql = "INSERT INTO admins (full_name, email, phone, office_id, sex, department, password_hash, verification_pic, verification_pic_hash, encryption_key) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $connect->prepare($sql);
    $stmt->bind_param("ssssssssss", $fullName, $encryptedEmail, $encryptedPhone, $officeId, $sex, $department, $hashedPassword, $encryptedVerificationPic, $verificationPicHash, $encryptionKey);

    if ($stmt->execute() === TRUE) {
        echo "<script>alert('User registered successfully!');</script>";
    } else {
        echo "Error: " . $stmt->error;
    }
}

function generateRandomString($length = 16) {
    return bin2hex(random_bytes($length / 2));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Registration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <link rel="icon" type="image/ico" href="favicon.ico">
    <style>
        .password-requirements {
            display: none;
            font-size: 0.875em;
            color: red;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-dark" data-bs-theme="dark">
        <div class="container-fluid">
            <a class="navbar-brand text-light">RockFORT</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav column align-items-center">
                    <a class="nav-link" href="../routes/candidate.php">Add Candidate</a>
                    <a class="nav-link" href="../routes/voters.php">Add Voters</a>
                    <a class="nav-link active" aria-current="page" href="../routes/register.php">Add Admins</a>
                    <a class="nav-link" href="../routes/sending.php">Send Credentials</a>
                    <a class="nav-link" href="../routes/sent_Mails.php">Sent Mails</a>
                    <a class="nav-link" href="../routes/result.php">View Result</a>
                    <a class="nav-link" href="../routes/reset_vote.php">Vote Reset</a>
                    <a class="nav-link" href="../routes/voter_del.php">Voter Remove</a>
                </div>
            </div>
            <a href="../index.html" class="btn text-end" style="background-color: light blue; color: black; padding: 3px 10px; border-radius: 8px; line-height: 1;">Log Out</a>
        </div>
    </nav>

    <div class="container mt-5">
        <h1 class="text-center">Admins Registration Form</h1><br>
        <div class="row justify-content-center mt-4">
            <div class="col-md-6">
                <form id="registrationForm" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                    <div class="mb-3">
                        <input type="text" placeholder="Full name" id="fullName" name="fullName" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <input type="email" placeholder="Email" id="email" name="email" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <input type="tel" id="phone" placeholder="Phone number" name="phone" pattern="[0-9]{10}" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <input type="text" id="officeId" placeholder="Office ID" name="officeId" maxlength="5" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="sex">Sex:</label>
                        <select id="sex" name="sex" class="form-select" required>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <input type="text" placeholder="Department" id="department" name="department" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <input type="password" placeholder="Password" id="password" name="password" class="form-control" required>
                        <div class="password-requirements" id="password-requirements">
                            Password must be at least 8 characters long, contain at least one uppercase letter, one lowercase letter, one number, and one special character.
                        </div>
                    </div>
                    <div class="mb-3">
                        <input type="password" placeholder="Confirm password" id="confirmPassword" name="confirmPassword" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="verificationPic">Verification Picture:</label>
                        <input type="file" id="verificationPic" name="verificationPic" accept="image/*" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Register</button>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', (event) => {
            const passwordInput = document.getElementById('password');
            const passwordRequirements = document.getElementById('password-requirements');
            const registrationForm = document.getElementById('registrationForm');

            passwordInput.addEventListener('input', () => {
                const password = passwordInput.value;
                const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

                if (!regex.test(password)) {
                    passwordRequirements.style.display = 'block';
                } else {
                    passwordRequirements.style.display = 'none';
                }
            });

            registrationForm.addEventListener('submit', (event) => {
                const password = document.getElementById('password').value;
                const confirmPassword = document.getElementById('confirmPassword').value;
                const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

                if (!regex.test(password)) {
                    alert('Password does not meet complexity requirements.');
                    event.preventDefault();
                } else if (password !== confirmPassword) {
                    alert('Passwords do not match.');
                    event.preventDefault();
                }
            });
        });
    </script>
</body>
</html>
