<?php
session_start();
include("../api/connect.php");

if (isset($_POST['reset'])) {
    $reset_query = "UPDATE users SET status = 0";
    if (mysqli_query($connect, $reset_query)) {
        $_SESSION['message'] = "Status reset successfully.";
    } else {
        $_SESSION['message'] = "Error resetting status: " . mysqli_error($connect);
    }
    header("Location: reset_vote.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link type="text/css" href="../css/style.css" rel="stylesheet">
    <title>E-Voting System</title>
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-dark" data-bs-theme="dark">
        <div class="container-fluid">
            <a class="navbar-brand text-light">RockFORT</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav coloumn align-items-center">
                    <a class="nav-link" href="../routes/candidate.php">Add Candidate</a>
                    <a class="nav-link" href="../routes/voters.php">Add Voters</a>
                    <a class="nav-link" href="../routes/register.php">Add Admins</a>
                    <a class="nav-link" href="../routes/sending.php">Send Credentials</a>
                    <a class="nav-link" href="../routes/sent_Mails.php">Sent Mails</a>
                    <a class="nav-link" href="../routes/result.php">View Result</a>
                    <a class="nav-link active" aria-current="page" href="reset_vote.php">Vote reset</a>
                    <a class="nav-link" href="../routes/voter_del.php">Voter Remove</a>
                </div>
            </div>
            <a href="../index.html" class="btn text-end" style="background-color: light blue; color:black; padding: 3px 10px; border-radius: 8px; line-height: 1;">Log Out</a>
        </div>
    </nav>
    <h1 class="text-center mt-4">Reset Result</h1>
    <br><br><br>
    <div style="text-align: center; background-color: rgba(248, 249, 250, 0);">
        <form action="reset_vote.php" method="POST">
            <button type="submit" name="reset" class="btn text-end" style="width: 150px; height: 50px;">Reset</button>
        </form>
    </div>
    <?php
if (isset($_SESSION['message'])) {
    echo '<script>alert("' . $_SESSION['message'] . '");</script>';
    unset($_SESSION['message']);
}
?>

</body>
</html>
