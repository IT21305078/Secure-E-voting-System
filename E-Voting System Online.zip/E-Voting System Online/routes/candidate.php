<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link type="text/css" href="../css/style.css" rel="stylesheet">
    <link rel="icon" type="image/ico" href="favicon.ico">
    <meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' https://cdn.jsdelivr.net; style-src 'self' https://cdn.jsdelivr.net; img-src 'self' data:; connect-src 'self'; font-src 'self' https://cdn.jsdelivr.net; frame-src 'none';">
    <title>E-Voting System</title>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-dark" data-bs-theme="dark">
    <div class="container-fluid">
        <a class="navbar-brand text-light">RockFORT</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav column align-items-center">
                <a class="nav-link active" aria-current="page" href="../routes/candidate.php">Add Candidate</a>
                <a class="nav-link" href="../routes/voters.php">Add Voters</a>
                <a class="nav-link " href="../routes/register.php">Add Admins</a>
                <a class="nav-link" href="../routes/sending.php">Send Credentials</a>
                <a class="nav-link" href="../routes/sent_Mails.php">Sent Mails</a>
                <a class="nav-link" href="../routes/result.php">View Result</a>
                <a class="nav-link" href="../routes/reset_vote.php">Vote Reset</a>
                <a class="nav-link" href="../routes/voter_del.php">Voter Remove</a>
            </div>
        </div>
        <a href="../index.html" class="btn text-end" style="background-color: lightblue; color:black; padding: 3px 10px; border-radius: 8px; line-height: 1;">Log Out</a>
    </div>
</nav>

<h1 class="text-center mt-4">Welcome to Admin Page</h1>
<h3 class="text-center mt-4">Candidate Registration Form</h3>

<div class="container form-body">
    <div class="row">
        <div class="form-holder">
            <div class="form-content">
                <div class="form-items">
                    <form class="requires-validation" enctype="multipart/form-data" action="../api/cand.php" method="POST" novalidate>
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                        <div class="col-md-12 mb-3">
                            <input class="form-control" type="text" name="name" placeholder="Full Name" required>
                        </div>
                        <div class="col-md-12 mb-3">
                            <input class="form-control" type="text" name="cadid" placeholder="Candidate ID" required>
                            <div class="valid-feedback">Candidate ID is valid!</div>
                            <div class="invalid-feedback">Candidate ID cannot be blank!</div>
                        </div>
                        <div class="col-md-12 mb-3">
                            <input class="form-control" type="tel" name="phonenumber" placeholder="Phone Number" required>
                        </div>
                        <div class="col-md-12 mt-3">
                            <label class="mb-3 mr-1" for="gender">Gender: </label>
                            <input type="radio" class="btn-check" name="gender" id="male" value="Male" autocomplete="off" required>
                            <label class="btn btn-sm btn-outline-secondary" for="male">Male</label>
                            <input type="radio" class="btn-check" name="gender" id="female" value="Female" autocomplete="off" required>
                            <label class="btn btn-sm btn-outline-secondary" for="female">Female</label>
                            <input type="radio" class="btn-check" name="gender" id="others" value="Others" autocomplete="off" required>
                            <label class="btn btn-sm btn-outline-secondary" for="others">Other</label>
                            <div><br>
                                <p><label for="file" class="btn" name="image" style="cursor: pointer;background-color:#97cfe5">Upload Image</label></p>
                                <p><input type="file" accept="image/*" name="image" id="file" required></p>
                            </div>
                            <div class="form-button mt-3 mb-3">
                                <button id="submit" type="submit" name="submit" class="btn btn-primary">Register</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
<script src="/index.js"></script>
<script type="module" src="/static/app.js"></script>
</body>
</html>
