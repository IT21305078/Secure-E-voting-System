<?php
include("../api/connect.php");
require '../vendor/autoload.php'; 

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


function generateRandomString($length = 16)
{
    return bin2hex(random_bytes($length / 2));
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $officeId = $_POST['officeId'];

    
    $sql = "SELECT email, encryption_key FROM users WHERE office_id = ?";
    $stmt = $connect->prepare($sql);
    $stmt->bind_param("s", $officeId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if (!$row) {
        die("Error: Office ID not found or expired");
    }

    $voterEmail = openssl_decrypt($row['email'], 'aes-256-cbc', $row['encryption_key'], 0, $row['encryption_key']);
   

    
    $mail = new PHPMailer(true);

    try {
        
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; 
        $mail->SMTPAuth = true;
        $mail->Username = 'dinshehas@gmail.com'; 
        $mail->Password = 'hfad yknl tawp jeef'; 
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        
        $mail->setFrom('dinshehas@gmail.com', 'ADMIN-RockFORT');
        $mail->addAddress($voterEmail);

        
        $mail->isHTML(true);
        $mail->Subject = 'Your voting Credentials';
        $mail->Body = 'Here are your login credentials:<br><br>' .
            'Password: ' . $_POST['password'] . '<br><br>' .
            'Please find the verification image attached.';

        
        $mail->addAttachment($_FILES['verificationPic']['tmp_name'], $_FILES['verificationPic']['name']);

        
        $mail->send();
        {
            
$mail->send();

$current_time = date("Y-m-d H:i:s");
$sqlUpdate = "UPDATE users SET sent_status = 1, sent_time = ? WHERE office_id = ?";
$stmtUpdate = $connect->prepare($sqlUpdate);
$stmtUpdate->bind_param("ss", $current_time, $officeId);
$stmtUpdate->execute();

echo '<script>
        alert("Credentials sent successfully");
     </script>';


        echo '<script>
                alert("Credentials sent successfully");
            </script>';
        }
    } catch (Exception $e) {
        echo '<script>
                alert("Error: Credentials could not be sent. Please try again later.");
            </script>';
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link type="text/css" href="../css/style.css" rel="stylesheet">
    <title>E-Voting System</title>
</head>

<body>

    <nav class="navbar navbar-expand-lg bg-dark" data-bs-theme="dark">
        <div class="container-fluid">
            <a class="navbar-brand text-light">RockFORT</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav coloumn align-items-center">
                    <a class="nav-link" href="../routes/candidate.php">Add Candidate</a>
                    <a class="nav-link" href="../routes/voters.php">Add Voters</a>
                    <a class="nav-link" href="../routes/register.php">Add Admins</a>
                    <a class="nav-link active" aria-current="page" href="../routes/sending.php">Send Credentials</a>
                    <a class="nav-link"  href="../routes/sent_Mails.php">Sent Mails</a>
                    <a class="nav-link" href="../routes/result.php">View Result</a>
                    <a class="nav-link" href="../routes/reset_vote.php">Vote reset</a>
                    <a class="nav-link" href="../routes/voter_del.php">Voter Remove</a>

                </div>
            </div>
            <a href="../index.html" class="btn text-end" style="background-color: light blue; color:black; padding: 3px 10px; border-radius: 8px; line-height: 1;">Log Out</a>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6 mx-auto">
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title text-center" style="color: black;">Send Credentials</h3>
                        <form action="" method="post" enctype="multipart/form-data">
                            <div class="mb-3">
                                
                                <input type="text" class="form-control" placeholder="Office ID" id="officeId" name="officeId" required>
                            </div>
                            <div class="mb-3">
                                
                                <input type="password" class="form-control"  placeholder="password"  id="password" name="password" required>
                            </div>
                            <div class="mb-3">
                                <label for="verificationPic" class="form-label">Verification Image</label>
                                <input type="file" class="form-control" id="verificationPic" name="verificationPic" accept="image/*" required>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary">Send Credentials</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

</html>