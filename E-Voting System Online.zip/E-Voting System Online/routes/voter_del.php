<?php
session_start();
include("../api/connect.php");

$check_query1 = mysqli_query($connect, "SELECT * FROM users");
$userdata1 = array();
while ($row1 = mysqli_fetch_assoc($check_query1)) {
    $decryptedEmail = openssl_decrypt($row1['email'], 'aes-256-cbc', $row1['encryption_key'], 0, $row1['encryption_key']);
    $decryptedPhone = openssl_decrypt($row1['phone'], 'aes-256-cbc', $row1['encryption_key'], 0, $row1['encryption_key']);

    $row1['email'] = $decryptedEmail;
    $row1['phone'] = $decryptedPhone;

    $userdata1[] = $row1;
}
$_SESSION['userdata1'] = $userdata1;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link type="text/css" href="../css/style.css" rel="stylesheet">
    <link rel="icon" type="image/ico" href="favicon.ico">
    <title>E-Voting System</title>
    <style>
        .form-holder {
            border: 1px solid #ccc;
            padding: 20px;
            margin-top: 50px;
            background: #f9f9f9;
        }
        .delete-btn {
            padding: 3px 10px; 
            background-color: red;
            border-color: red;
            border: none;
        }
        .delete-btn:hover {
            background-color: darkred;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-dark" data-bs-theme="dark">
    <div class="container-fluid">
        <a class="navbar-brand text-light">RockFORT</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav column align-items-center">
                <a class="nav-link" href="../routes/candidate.php">Add Candidate</a>
                <a class="nav-link" href="../routes/voters.php">Add Voters</a>
                <a class="nav-link" href="../routes/register.php">Add Admins</a>
                <a class="nav-link" href="../routes/sending.php">Send Credentials</a>
                <a class="nav-link" href="../routes/sent_Mails.php">Sent Mails</a>
                <a class="nav-link" href="../routes/result.php">View Result</a>
                <a class="nav-link" href="../routes/reset_vote.php">Vote Reset</a>
                <a class="nav-link active" aria-current="page" href="../routes/voter_del.php">Voter Remove</a>
            </div>
        </div>
        <a href="../index.html" class="btn text-end" style="background-color: light blue; color:black; padding: 3px 10px; border-radius: 8px; line-height: 1;">Log Out</a>
    </div>
</nav>

<h1 class="text-center mt-4">Delete Voter</h1>
<div class="container form-body">
    <div class="row">
        <div class="col-12 form-holder">
            <?php
            if (!empty($userdata1)) {
                echo "<table class='table table-bordered'>";
                echo "<thead class='table-dark'>";
                echo "<tr>";
                echo "<th>Name</th>";
                echo "<th>OfcID</th>";
                echo "<th>Department</th>";
                echo "<th>Sex</th>";
                echo "<th>Email</th>";
                echo "<th>Phone</th>";
                echo "<th></th>";
                echo "</tr>";
                echo "</thead>";
                echo "<tbody>";
                foreach ($userdata1 as $voter) {
                    echo "<tr>";
                    echo "<td>" . $voter['full_name'] . "</td>";
                    echo "<td>" . $voter['office_id'] . "</td>";
                    echo "<td>" . $voter['department'] . "</td>";
                    echo "<td>" . $voter['sex'] . "</td>";
                    echo "<td>" . $voter['email'] . "</td>";
                    echo "<td>" . $voter['phone'] . "</td>";
                    echo '<td>';
                    echo '<form action="../api/vdel.php" method="POST" style="display: inline;">';
                    echo '<input type="hidden" name="voterid" value="' . $voter['office_id'] . '">';
                    echo '<button type="submit" name="delbtn" class="btn btn-danger delete-btn" style="background-color: red; border-color: red;">Delete</button>';

                    echo '</form>';
                    echo '</td>';
                    echo "</tr>";
                }
                echo "</tbody>";
                echo "</table>";
            } else {
                echo "<div style='border-bottom: 1px solid #bdc3c7; margin-bottom: 10px'>";
                echo "<b>No Voters available right now.</b>";
                echo "</div>";
            }
            ?>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
