<?php
session_start();
include('../api/connect.php');

// Fetch candidates data securely
$qsql = "SELECT * FROM candidate";
$stmt = $connect->prepare($qsql);
$stmt->execute();
$result1 = $stmt->get_result();
$groupdata1 = mysqli_fetch_all($result1, MYSQLI_ASSOC);

$stmt->close();
$connect->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link type="text/css" href="../css/style.css" rel="stylesheet">
    <title>E-Voting System</title>
    <style>
        @keyframes fadeIn {
            0% { opacity: 0; }
            100% { opacity: 1; }
        }
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }
        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
            40% { transform: translateY(-30px); }
            60% { transform: translateY(-15px); }
        }
        @keyframes colorChange {
            0% { color: red; }
            50% { color: green; }
            100% { color: red; }
        }
        body {
            background-color: lightblue;
            text-align: center;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }
        .winner-text {
            margin-top: 20%;
        }
        .winner-text .title {
            font-size: 4em;
            animation: fadeIn 1s ease-in-out, bounce 2s infinite, colorChange 3s infinite;
        }
        .winner-text .candidate {
            font-size: 3em;
            animation: fadeIn 2s ease-in-out, pulse 1.5s infinite, colorChange 3s infinite;
        }
        .winner-text .votes {
            font-size: 2em;
            animation: fadeIn 3s ease-in-out;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-dark" data-bs-theme="dark">
        <div class="container-fluid">
            <a class="navbar-brand text-light">RockFORT</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav column align-items-center">
                    <a class="nav-link" href="../routes/candidate.php">Add Candidate</a>
                    <a class="nav-link" href="../routes/voters.php">Add Voters</a>
                    <a class="nav-link" href="../routes/register.php">Add Admins</a>
                    <a class="nav-link" href="../routes/sending.php">Send Credentials</a>
                    <a class="nav-link" href="../routes/sent_Mails.php">Sent Mails</a>
                    <a class="nav-link active" aria-current="page" href="../routes/result.php">View Result</a>
                    <a class="nav-link" href="../routes/reset_vote.php">Vote reset</a>
                    <a class="nav-link" href="../routes/voter_del.php">Voter Remove</a>
                </div>
            </div>
            <a href="../index.html" class="btn text-end" style="background-color: light blue; color:black; padding: 3px 10px; border-radius: 8px; line-height: 1;">Log Out</a>
        </div>
    </nav>
          
    <h1 class="text-center mt-4" style="color: red;">Election Result</h1><br><br>

    
    <form class="requires-validation" novalidate>
        <div>
        <?php 
            $max_votes = 0;
            $top_candidate = '';

            if (!empty($groupdata1)): 
                foreach($groupdata1 as $candidate)
                {
                    if ($candidate['votes'] > $max_votes) {
                        $max_votes = $candidate['votes'];
                        $top_candidate = $candidate['name'];
                    }
                }

                echo '<div class="winner-text">
                        <div class="title">🏆</div>
                        <div><h3 style="color: blue;">WINNER</h3></div>

                        <div class="candidate">' . htmlspecialchars($top_candidate) . '</div>
                        <div class="votes">' . htmlspecialchars($max_votes) . ' votes</div>
                      </div>';
            else:
                echo '<div class="winner-text"><div class="title">No candidates found.</div></div>';
            endif;
        ?><br>
        </div>
        <div style="text-align: center;">
            <a href="./viewdetails.php" class="btn text-end">View Details</a>
        </div>
    </form>
                  
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76A58aypDQ10B8lCLvfbMk5Cuwf7It6j4EZnjsL5rL5BSy8YfmnJ2B4cw3r9pC7" crossorigin="anonymous"></script>
</body>
</html>
