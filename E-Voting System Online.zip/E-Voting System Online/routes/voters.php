<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voters Registration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <style>
        .password-requirements {
            display: none;
            font-size: 0.875em;
            color: red;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-dark" data-bs-theme="dark">
        <div class="container-fluid">
            <a class="navbar-brand text-light">RockFORT</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav coloumn align-items-center">
                    <a class="nav-link" href="../routes/candidate.php">Add Candidate</a>
                    <a class="nav-link active" aria-current="page" href="../routes/voters.php">Add Voters</a>
                    <a class="nav-link" href="../routes/register.php">Add Admins</a>
                    <a class="nav-link" href="../routes/sending.php">Send Credentials</a>
                    <a class="nav-link" href="../routes/sent_Mails.php">Sent Mails</a>
                    <a class="nav-link" href="../routes/result.php">View Result</a>
                    <a class="nav-link" href="../routes/reset_vote.php">Vote Reset</a>
                    <a class="nav-link" href="../routes/voter_del.php">Voter Remove</a>
                </div>
            </div>
            <a href="../index.html" class="btn text-end" style="background-color: light blue; color: black; padding: 3px 10px; border-radius: 8px; line-height: 1;">Log Out</a>
        </div>
    </nav>

    <div class="container mt-5">
        <h1 class="text-center">Voters Registration Form</h1>
        <div class="form-holder">
            <div class="row justify-content-center mt-4">
                <div class="col-md-6">
                    <form id="registrationForm" action="../api/voter.php" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                        <div class="mb-3">
                            <input type="text" placeholder="Full name" class="form-control" id="fullName" name="fullName" required>
                        </div>
                        <div class="mb-3">
                            <input type="email" placeholder="Email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <input type="tel" class="form-control" placeholder="Phone number" id="phone" name="phone" pattern="[0-9]{10}" required>
                        </div>
                        <div class="mb-3">
                            <input type="text" class="form-control" placeholder="Office ID" id="officeId" name="officeId" maxlength="5" required>
                        </div>
                        <div class="mb-3">
                            <select class="form-select" id="sex" name="sex" required>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <input type="text" class="form-control" placeholder="Department" id="department" name="department" required>
                        </div>
                        <div class="mb-3">
                            <input type="password" placeholder="Password" class="form-control" id="password" name="password" required>
                            <div class="password-requirements" id="password-requirements">
                                Password must be at least 8 characters long, contain at least one uppercase letter, one lowercase letter, one number, and one special character.
                            </div>
                        </div>
                        <div class="mb-3">
                            <input type="password" placeholder="Confirm password" class="form-control" id="confirmPassword" name="confirmPassword" required>
                        </div>
                        <div class="mb-3">
                            <label for="verificationPic" class="form-label">Verification Picture:</label>
                            <input type="file" class="form-control" id="verificationPic" name="verificationPic" accept="image/*" required>
                        </div>
                        <div class="mb-3">
                            <input type="hidden" id="txtIsoTemplate" name="txtIsoTemplate">
                        </div>
                        <div class="mb-3 text-center">
                            <button type="button" class="btn btn-primary" onclick="captureFingerprint()">Capture Fingerprint</button>
                        </div>
                        <div class="mb-3 text-center">
                            <img id="imgFinger" src="" alt="Finger Image" style="border: 1px solid #DDDDDD; height: 140px; width: 140px;">
                        </div>
                        <div class="mb-3 text-center">
                            <button type="submit" class="btn btn-success">Register</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="./mfs100.js"></script>
    <script>
        function captureFingerprint() {
            var quality = 60; 
            var timeout = 10; 

            var res = CaptureFinger(quality, timeout);
            if (res.httpStaus) {
                document.getElementById('txtStatus').value = "ErrorCode: " + res.data.ErrorCode + " ErrorDescription: " + res.data.ErrorDescription;
                if (res.data.ErrorCode == "0") {
                    document.getElementById('imgFinger').src = "data:image/bmp;base64," + res.data.BitmapData;
                    var imageinfo = "Quality: " + res.data.Quality + " Nfiq: " + res.data.Nfiq + " W(in): " + res.data.InWidth + " H(in): " + res.data.InHeight + " area(in): " + res.data.InArea + " Resolution: " + res.data.Resolution + " GrayScale: " + res.data.GrayScale + " Bpp: " + res.data.Bpp + " WSQCompressRatio: " + res.data.WSQCompressRatio;
                    document.getElementById('txtImageInfo').value = imageinfo;
                    document.getElementById('txtIsoTemplate').value = res.data.IsoTemplate;
                }
            } else {
                alert(res.err);
            }
        }

        $(document).ready(function() {
            $('#password').on('input', function() {
                var password = $(this).val();
                var regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
                if (!regex.test(password)) {
                    $('#password-requirements').show();
                } else {
                    $('#password-requirements').hide();
                }
            });

            $('#registrationForm').on('submit', function(e) {
                var password = $('#password').val();
                var confirmPassword = $('#confirmPassword').val();
                var regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
                if (!regex.test(password)) {
                    alert('Password does not meet complexity requirements.');
                    e.preventDefault();
                } else if (password !== confirmPassword) {
                    alert('Passwords do not match.');
                    e.preventDefault();
                }
            });
        });
    </script>
</body>
</html>
