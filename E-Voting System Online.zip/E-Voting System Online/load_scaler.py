import pickle

# Load the scaler
scaler_path = 'C:/xampp/htdocs/E-Voting System Online/scaler.pkl'

try:
    with open(scaler_path, 'rb') as scaler_file:
        scaler = pickle.load(scaler_file)
except Exception as e:
    print(f"Error loading scaler: {e}")
    exit()

# Print scaler attributes
print("Scaler attributes:")
print(f"Mean: {scaler.mean_}")
print(f"Scale: {scaler.scale_}")
print(f"Var: {scaler.var_}")
print(f"n_samples_seen: {scaler.n_samples_seen_}")
