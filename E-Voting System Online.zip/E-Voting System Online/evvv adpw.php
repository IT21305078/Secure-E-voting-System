<?php


include('api/connect.php');

require 'voterlg/PHPMailer-master/src/PHPMailer.php';
require 'voterlg/PHPMailer-master/src/SMTP.php';
require 'voterlg/PHPMailer-master/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


if (!isset($_SERVER['HTTPS']) || $_SERVER['HTTPS'] !== 'on') {
    header("Location: https://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
    exit();
}


session_set_cookie_params([
    'lifetime' => 0, 
    'path' => '/',
    'domain' => $_SERVER['HTTP_HOST'],
    'secure' => true,
    'httponly' => true, 
    'samesite' => 'Strict' 
]);

session_start();

function generateOTP($length = 6) {
    $otp = "";
    $characters = "0123456789";
    $charLength = strlen($characters);
    for ($i = 0; $i < $length; $i++) {
        $otp .= $characters[rand(0, $charLength - 1)];
    }
    return $otp;
}

function decryptEmail($encryptedEmail, $encryptionKey) {
    return openssl_decrypt($encryptedEmail, 'aes-256-cbc', $encryptionKey, 0, substr($encryptionKey, 0, 16));
}

function isValidCaptcha($userCaptcha) {
    return isset($_SESSION['captcha']) && $_SESSION['captcha'] === $userCaptcha;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['officeId'], $_POST['password'], $_POST['csrf_token'], $_POST['captcha'])) {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die('Invalid CSRF token');
    }

    if (!isValidCaptcha($_POST['captcha'])) {
        $error_message = "Invalid CAPTCHA.";
    } else {
        $officeId = htmlspecialchars(trim($_POST['officeId']));
        $password = htmlspecialchars(trim($_POST['password']));

        $sql = "SELECT * FROM admins WHERE office_id = ?";
        $stmt = $connect->prepare($sql);
        $stmt->bind_param("s", $officeId);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if (password_verify($password, $row["password_hash"])) {
                $otp = generateOTP();
                $_SESSION['otp'] = $otp;
                $_SESSION['otp_expiry'] = time() + 300; 
                $_SESSION['office_id'] = $officeId;

                $decryptedEmail = decryptEmail($row['email'], $row['encryption_key']);

                $mail = new PHPMailer(true);
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'dinshehas@gmail.com'; 
                $mail->Password = 'hfad yknl tawp jeef'; 
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                $mail->setFrom('dinshehas@gmail.com', 'RockFORT Voting');
                $mail->addAddress($decryptedEmail); 

                $mail->isHTML(true);
                $mail->Subject = 'OTP for E-voting Admin Panel Access';
                $mail->Body = 'Your OTP is: <strong>' . $otp . '</strong>';

                if ($mail->send()) {
                    header("Location: otp_verification.php");
                    exit();
                } else {
                    $error_message = 'Mailer Error: ' . $mail->ErrorInfo;
                }
            } else {
                $error_message = "Invalid password.";
            }
        } else {
            $error_message = "Invalid office ID.";
        }
    }
}

$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/stl.css">
    <style>
        body {
            background-color: #b6c4ff;
            font-family: Arial, sans-serif;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .card {
            width: 400px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .card-header {
            background-color: #434963;
            color: #fff;
            border-radius: 15px 15px 0 0;
            padding: 20px;
            text-align: center;
        }
        .card-body {
            padding: 20px;
        }
        .form-label {
            font-weight: bold;
        }
        .btn-primary {
            width: 100%;
        }
        .navbar {
            background-color: #343a40; 
        }
        .navbar-brand {
            color: #ffffff; 
        }
        .navbar-toggler-icon {
            color: #ffffff; 
        }
        .nav-link {
            color: #ffffff !important; 
        }
        .forgot-password {
            color: darkgrey;
            text-decoration: underline;
            border: none;
            background: none;
            cursor: pointer;
            padding: 0;
            margin: 0;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-dark" data-bs-theme="dark">
    <div class="container-fluid">
        <a class="navbar-brand text-light">RockFORT</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav ms-auto">
                <a href="index.html" class="nav-link" style="background-color: #007bff; color: #ffffff; border-radius: 8px; padding: 8px 16px; text-decoration: none;">Go Back</a>
            </div>
        </div>
    </div>
</nav>

<div class="container">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Admin Login</h3>
        </div>
        <div class="card-body">
            <?php if (!empty($error_message)): ?>
                <div class="alert alert-danger"><?php echo $error_message; ?></div>
            <?php endif; ?>
            <form id="loginForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                <div class="mb-3">
                    <input type="text" class="form-control" id="officeId" name="officeId" placeholder="Office ID" required>
                </div>
                <div class="mb-3">
                    <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                </div>
                <div class="mb-3">
                    <img src="voterlg/captcha.php" alt="CAPTCHA"><br>
                    <input type="text" class="form-control" id="captcha" name="captcha" placeholder="Captcha" required>
                </div>
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <button type="submit" class="btn btn-primary">Login</button>
            </form>
            <form id="forgotPasswordForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                <br><button type="submit" name="forgot_password" class="forgot-password">Forgot Password?</button>
                <div class="mb-3">
                    <input type="text" class="form-control" id="officeId" name="officeId" placeholder="Office ID" required>
                </div>
            </form>
            <div class="mt-3 text-center">
                <p>Or</p>
                <form action="voterlg/voterfig.php" method="GET">
                    <div class="mb-3">
                        <input type="text" class="form-control" id="officeIdFingerprint" name="officeId" placeholder="Office ID" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Use Fingerprint</button>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-6vIhYov5XU5S/WmLFh/SYZQ/b17IRF1gZfQRTVye9rbl4blpefwLA7FZlmNBllZT" crossorigin="anonymous"></script>
</body>
</html>
