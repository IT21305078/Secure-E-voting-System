

<?php



if (!isset($_SERVER['HTTPS']) || $_SERVER['HTTPS'] !== 'on') {
    header("Location: https://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
    exit();
}


session_set_cookie_params([
    'lifetime' => 0, 
    'path' => '/',
    'domain' => $_SERVER['HTTP_HOST'],
    'secure' => true, 
    'httponly' => true, 
    'samesite' => 'Strict' 
]);

session_start();
ob_start();


if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function displayForm($message = '') {
    $csrf_token = $_SESSION['csrf_token'];
    echo '<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>OTP Verification</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
        <style>
            body {
                background-color:#b6c4ff;
                font-family: Arial, sans-serif;
            }
            .container {
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
            }
            .card {
                width: 400px;
                border-radius: 15px;
                box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            }
            .card-header {
                background-color: #434963;
                color: #fff;
                border-radius: 15px 15px 0 0;
                padding: 20px;
                text-align: center;
            }
            .card-body {
                padding: 20px;
            }
            .form-label {
                font-weight: bold;
            }
            .btn-primary {
                width: 100%;
            }
        </style>
    </head>
    <body>
    <nav class="navbar navbar-expand-lg bg-dark" data-bs-theme="dark">
    <div class="container-fluid">
        <a class="navbar-brand text-light">RockFORT</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav ms-auto">
                <a href="index.html" class="nav-link" style="background-color: #007bff; color: #ffffff; border-radius: 8px; padding: 8px 16px; text-decoration: none;">Go Back</a>
            </div>
        </div>
    </div>
</nav>

        <div class="container">
            <div class="card">
                <div class="card-header">Enter OTP</div>
                <div class="card-body">
                    '. (!empty($message) ? '<div class="alert alert-danger">'.$message.'</div>' : '') .'
                    <form action="" method="post">
                        <div class="mb-3">
                            <input type="text" id="otp" name="otp" class="form-control" placeholder="OTP" required autofocus>
                        </div>
                        <input type="hidden" name="csrf_token" value="'.$csrf_token.'">
                        <button type="submit" class="btn btn-primary">Verify OTP</button>
                    </form>
                </div>
            </div>
        </div>
    </body>
    </html>';
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['otp'], $_POST['csrf_token'])) {
   
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die('Invalid CSRF token');
    }

    $enteredOTP = htmlspecialchars(trim($_POST['otp']));

    
    if ($enteredOTP === $_SESSION['otp'] && time() < $_SESSION['otp_expiry']) {
       
        session_regenerate_id(true);
        header('Location: evvv adpic.php');
        exit();
    } else {
        if (time() >= $_SESSION['otp_expiry']) {
            $error = "OTP has expired. Please request a new one.";
        } else {
            $error = "Invalid OTP. Please try again.";
        }
        displayForm($error);
    }
} else {
    displayForm();
}

ob_end_flush();
?>
