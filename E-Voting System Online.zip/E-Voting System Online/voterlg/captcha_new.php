<?php
session_start();

$captchaText = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 6);

$_SESSION['captcha'] = $captchaText;

header('Content-type: image/png');

$image = imagecreatetruecolor(200, 50);

$backgroundColor = imagecolorallocate($image, 255, 255, 255);
imagefill($image, 0, 0, $backgroundColor);

for ($i = 0; $i < 100; $i++) {
    $x = rand(0, 200);
    $y = rand(0, 50);
    $color = imagecolorallocate($image, rand(0, 255), rand(0, 255), rand(0, 255));
    imagesetpixel($image, $x, $y, $color);
}

$fontDir = __DIR__ . '/fonts/';
$fonts = glob($fontDir . '*.ttf');
if (empty($fonts)) {
    die("No font files found in directory: $fontDir");
}

for ($i = 0; $i < 6; $i++) {
    $fontSize = rand(20, 30);
    $angle = rand(-30, 30);
    $x = 20 + ($i * 30);
    $y = rand(30, 40);
    $color = imagecolorallocate($image, rand(0, 100), rand(0, 100), rand(0, 100));
    $fontFile = $fonts[array_rand($fonts)];
    imagettftext($image, $fontSize, $angle, $x, $y, $color, $fontFile, $captchaText[$i]);
}

$imageDistorted = imagecreatetruecolor(200, 50);
imagefill($imageDistorted, 0, 0, $backgroundColor);
imagecopyresampled($imageDistorted, $image, 0, 0, 10, 5, 200, 50, 180, 40);

imagepng($imageDistorted);

imagedestroy($image);
imagedestroy($imageDistorted);
?>
