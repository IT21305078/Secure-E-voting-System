<?php
session_start();
include("../api/connect.php");

if (!isset($_SESSION['office_id'])) {
    header("Location: userpw.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES['verificationPic'])) {
    $officeId = $_SESSION['office_id'];
    $uploadedPicTmpName = $_FILES['verificationPic']['tmp_name'];

    if (!is_uploaded_file($uploadedPicTmpName) || !exif_imagetype($uploadedPicTmpName)) {
        die("Error: Uploaded file is not a valid image.");
    }

    $uploadedPicContent = file_get_contents($uploadedPicTmpName);
    $uploadedPicHash = hash_file('sha256', $uploadedPicTmpName);

    $sql = "SELECT * FROM users WHERE office_id=?";
    $stmt = $connect->prepare($sql);
    $stmt->bind_param("s", $officeId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $storedPicHash = $row["verification_pic_hash"];

        if ($storedPicHash === $uploadedPicHash) {
            $encryptionKey = $row["encryption_key"];
            $storedEncryptedPic = $row["verification_pic"];

            $storedPic = openssl_decrypt($storedEncryptedPic, 'aes-256-cbc', $encryptionKey, 0, $encryptionKey);

            if (compareImages($storedPic, $uploadedPicContent)) {
                $votes = filter_input(INPUT_POST, 'gvotes', FILTER_SANITIZE_NUMBER_INT);
                $total_votes = $votes + 1;
                $gname = filter_input(INPUT_POST, 'gname', FILTER_SANITIZE_STRING);
                $vid = filter_input(INPUT_POST, 'vid', FILTER_SANITIZE_STRING);

                $update_votes = mysqli_query($connect, "UPDATE candidate SET votes='$total_votes' WHERE name='$gname'");
                $update_user_status = mysqli_query($connect, "UPDATE users SET status = 1 WHERE office_id='$officeId'");

                if ($update_votes && $update_user_status) {
                    $groups = mysqli_query($connect, "SELECT * FROM candidate");
                    $groupdata = array();
                    while ($row = mysqli_fetch_assoc($groups)) {
                        $groupdata[] = $row;
                    }
                    $_SESSION['groupdata'] = $groupdata;
                    $_SESSION['userdata']['status'] = 1;
                    echo '
                        <script>
                            alert("Vote Saved!");
                            window.location = "../voterlg/logout.php";
                        </script>';
                    exit(); 
                } else {
                    echo '
                        <script>
                            alert("Error Occurred");
                            window.location = "../voterlg/voterlogin.php";
                        </script>';
                    exit(); 
                }
            } else {
                echo "Uploaded picture does not match the stored picture.";
            }
        } else {
            echo "Uploaded picture hash does not match the stored hash.";
        }
    } else {
        echo "Invalid office ID.";
    }
}

function compareImages($imageData1, $imageData2) {
    $image1 = imagecreatefromstring($imageData1);
    $image2 = imagecreatefromstring($imageData2);

    $width1 = imagesx($image1);
    $height1 = imagesy($image1);
    $width2 = imagesx($image2);
    $height2 = imagesy($image2);

    if ($width1 !== $width2 || $height1 !== $height2) {
        return false;
    }

    for ($x = 0; $x < $width1; $x++) {
        for ($y = 0; $y < $height1; $y++) {
            $pixelColor1 = imagecolorat($image1, $x, $y);
            $pixelColor2 = imagecolorat($image2, $x, $y);

            $red1 = ($pixelColor1 >> 16) & 0xFF;
            $green1 = ($pixelColor1 >> 8) & 0xFF;
            $blue1 = $pixelColor1 & 0xFF;

            $red2 = ($pixelColor2 >> 16) & 0xFF;
            $green2 = ($pixelColor2 >> 8) & 0xFF;
            $blue2 = $pixelColor2 & 0xFF;

            if ($red1 !== $red2 || $green1 !== $green2 || $blue1 !== $blue2) {
                imagedestroy($image1);
                imagedestroy($image2);
                return false;
            }
        }
    }

    imagedestroy($image1);
    imagedestroy($image2);
    return true;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Picture Upload</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/stl.css">
    <style>
        body {
            background-color: #b6c4ff;
            font-family: Arial, sans-serif;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .card {
            width: 400px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .card-header {
            background-color: #434963;
            color: #fff;
            border-radius: 15px 15px 0 0;
            padding: 20px;
            text-align: center;
        }
        .card-body {
            padding: 20px;
        }
        .form-label {
            font-weight: bold;
        }
        .btn-primary {
            width: 100%;
        }
        .navbar {
            background-color: #343a40; 
        }
        .navbar-brand {
            color: #ffffff; 
        }
        .navbar-toggler-icon {
            color: #ffffff; 
        }
        .nav-link {
            color: #ffffff !important; 
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-dark" data-bs-theme="dark">
    <div class="container-fluid">
        <a class="navbar-brand text-light">RockFORT</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav ms-auto">
                <a href="../index.html" class="nav-link">Go Back</a>
            </div>
        </div>
    </div>
</nav>

<div class="container">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Upload Verification Picture</h3>
        </div>
        <div class="card-body">
            <form id="uploadForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <input type="file" id="verificationPic" name="verificationPic" accept="image/*" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary">Upload</button>
            </form>
        </div>
    </div>
</div>
</body>
</html>
