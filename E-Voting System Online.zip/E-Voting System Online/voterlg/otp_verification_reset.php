<?php

if (!isset($_SERVER['HTTPS']) || $_SERVER['HTTPS'] !== 'on') {
    header('Location: https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
    exit();
}

if (session_status() === PHP_SESSION_NONE) {
   
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => $_SERVER['HTTP_HOST'],
        'secure' => true,
        'httponly' => true,
        'samesite' => 'Strict'
    ]);
    session_start();
}

require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';
require 'PHPMailer-master/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

function generateOTP($length = 6) {
    $otp = "";
    $characters = "0123456789";
    $charLength = strlen($characters);
    for ($i = 0; $i < $length; $i++) {
        $otp .= $characters[rand(0, $charLength - 1)];
    }
    return $otp;
}

$logFilePath = 'login_logs.txt';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['otp'])) {
    $enteredOTP = filter_input(INPUT_POST, 'otp', FILTER_SANITIZE_STRING);

    if (isset($_SESSION['otp']) && isset($_SESSION['otp_expiry'])) {
        
        if ($enteredOTP == $_SESSION['otp'] && time() < $_SESSION['otp_expiry']) {
            $_SESSION['invalid_otp_attempts'] = 0; 
            
            if (isset($_GET['reset_password']) && $_GET['reset_password'] == 'true') {
                header("Location: reset_password.php");
            } else {
                $_SESSION['office_id'] = $_SESSION['row']['office_id'];
                header("Location: votingevv.php");
            }
            exit();
        } else {
            if (!isset($_SESSION['invalid_otp_attempts'])) {
                $_SESSION['invalid_otp_attempts'] = 0;
            }
            $_SESSION['invalid_otp_attempts']++;
            
            if ($_SESSION['invalid_otp_attempts'] >= 3) {
                echo "Too many invalid OTP attempts. Account locked.";
                exit();
            }

            echo "Invalid OTP or OTP expired.";
            $logMessage = "[" . date("Y-m-d H:i:s") . "] Invalid OTP or OTP expired for office ID: {$_SESSION['row']['office_id']}\n";
            file_put_contents($logFilePath, $logMessage, FILE_APPEND);
        }
    } else {
        echo "OTP session not found.";
        $logMessage = "[" . date("Y-m-d H:i:s") . "] OTP session not found for office ID: {$_SESSION['row']['office_id']}\n";
        file_put_contents($logFilePath, $logMessage, FILE_APPEND);
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['resend'])) {
    if (!isset($_SESSION['resend_attempts'])) {
        $_SESSION['resend_attempts'] = 0;
    }
    if ($_SESSION['resend_attempts'] >= 3) {
        echo "Too many resend attempts. Account locked.";
        exit();
    }

    if (isset($_SESSION['decryptedEmail']) && isset($_SESSION['row'])) {
        $decryptedEmail = $_SESSION['decryptedEmail'];
        $row = $_SESSION['row'];

        $otp = generateOTP();
        $_SESSION['otp'] = $otp;
        $_SESSION['otp_expiry'] = time() + (4 * 60); 

        $mail = new PHPMailer();
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'dinshehas@gmail.com'; 
        $mail->Password = 'hfad yknl tawp jeef'; 
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('dinshehas@gmail.com', 'Din'); 
        $mail->addAddress($decryptedEmail, $row['full_name']); 

        $mail->Subject = 'One Time Password (OTP) for Login';
        $mail->Body = 'Your OTP is: ' . $otp;

        if ($mail->send()) {
            echo '<script>alert("OTP resent successfully!");</script>';
            $logMessage = "[" . date("Y-m-d H:i:s") . "] OTP resent successfully for office ID: {$row['office_id']}\n";
            file_put_contents($logFilePath, $logMessage, FILE_APPEND);
        } else {
            echo 'Failed to send OTP. Please try again later.';
            echo 'Error: ' . $mail->ErrorInfo;
            $logMessage = "[" . date("Y-m-d H:i:s") . "] Failed to send OTP for office ID: {$row['office_id']}\n";
            file_put_contents($logFilePath, $logMessage, FILE_APPEND);
        }

        $_SESSION['resend_attempts']++;
    } else {
        echo 'Failed to send OTP. Email address or user data not found.';
        $logMessage = "[" . date("Y-m-d H:i:s") . "] Failed to send OTP. Email address or user data not found.\n";
        file_put_contents($logFilePath, $logMessage, FILE_APPEND);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTP Verification</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/stl.css">
    <style>
        body {
            background-color: #b6c4ff;
            font-family: Arial, sans-serif;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            border-radius: 10px;
        }
        .card {
            width: 400px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .card-header {
            background-color: #434963;
            color: #fff;
            border-radius: 15px 15px 0 0;
            padding: 20px;
            text-align: center;
        }
        .card-body {
            padding: 20px;
        }
        .form-label {
            font-weight: bold;
        }
        .btn-primary {
            background-color: #007bff; 
            border-color: #007bff;
            width: auto; 
        }
        .btn-primary:hover {
            background-color: #0056b3; 
            border-color: #0056b3;
        }
        .btn-link {
            background-color: #D3D3D3;
            color: #6c757d; 
            text-decoration: none !important; 
        }
        .btn-link:hover {
            color: #545b62; 
        }
        .navbar {
            background-color: #343a40; 
        }
        .navbar-brand {
            color: #ffffff; 
        }
        .navbar-toggler-icon {
            color: #ffffff; 
        }
        .nav-link {
            background-color: #007bff;
            color: #ffffff !important; 
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-dark" data-bs-theme="dark">
    <div class="container-fluid">
        <a class="navbar-brand text-light">RockFORT</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav ms-auto">
                <a href="../index.html" class="btn btn-primary">Go Back</a>
            </div>
        </div>
    </div>
</nav>

<div class="container">
    <div class="card">
        <div class="card-header">
            OTP Verification
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="mb-3">
                    <input type="text" placeholder="Enter OTP" class="form-control" id="otp" name="otp" required>
                </div>
                <button type="submit" class="btn btn-primary">Verify OTP</button>
            </form>
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <button type="submit" class="btn btn-link" name="resend" style="color: white; text-decoration: underline; border: none; background: none; cursor: pointer;">Resend OTP</button>
            </form>
        </div>
    </div>
</div>
</body>
</html>
