<?php

if (!isset($_SERVER['HTTPS']) || $_SERVER['HTTPS'] !== 'on') {
    header('Location: https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
    exit();
}

if (session_status() === PHP_SESSION_NONE) {
   
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => $_SERVER['HTTP_HOST'],
        'secure' => true,
        'httponly' => true,
        'samesite' => 'Strict'
    ]);
    session_start();
}

include("../api/connect.php");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-master/src/Exception.php';
require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';

ob_start();

function generateOTP($length = 6) {
    $otp = "";
    $characters = "0123456789";
    $charLength = strlen($characters);
    for ($i = 0; $i < $length; $i++) {
        $otp .= $characters[rand(0, $charLength - 1)];
    }
    return $otp;
}

function detectFraud($data) {
    $url = 'http://127.0.0.1:5000/detect_fraud';
    $options = array(
        'http' => array(
            'header' => "Content-Type: application/json\r\n",
            'method' => 'POST',
            'content' => json_encode($data),
        ),
    );
    $context = stream_context_create($options);
    $result = file_get_contents($url, false, $context);
    if ($result === FALSE) {
        return ['error' => 'Failed to connect to the API.'];
    }

    $response = json_decode($result, true);
    if (isset($response['error'])) {
        return ['error' => $response['error']];
    }

    return $response['result'];
}

if (!isset($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = [];
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['officeId']) && isset($_POST['password']) && isset($_POST['captcha'])) {
        $officeId = filter_input(INPUT_POST, 'officeId', FILTER_SANITIZE_STRING);
        $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
        $enteredCaptcha = filter_input(INPUT_POST, 'captcha', FILTER_SANITIZE_STRING);

        if (!isset($_SESSION['login_attempts'][$officeId]) || !is_array($_SESSION['login_attempts'][$officeId])) {
            $_SESSION['login_attempts'][$officeId] = [
                'password' => 0,
                'captcha' => 0
            ];
        }

        if ($_SESSION['login_attempts'][$officeId]['captcha'] >= 3) {
            echo '<script>alert("Too many invalid CAPTCHA attempts. Account locked.");</script>';
            file_put_contents('login_logs.txt', "[" . date("Y-m-d H:i:s") . "] Too many invalid CAPTCHA attempts. Account locked for office ID: $officeId\n", FILE_APPEND);
            exit();
        }

        if (strtolower($_SESSION['captcha']) !== strtolower($enteredCaptcha)) {
            echo '<script>alert("Invalid CAPTCHA.");</script>';
            $_SESSION['login_attempts'][$officeId]['captcha']++;
            file_put_contents('login_logs.txt', "[" . date("Y-m-d H:i:s") . "] Invalid CAPTCHA for office ID: $officeId\n", FILE_APPEND);
           
        }

        $sql = "SELECT * FROM users WHERE office_id = ?";
        $stmt = mysqli_prepare($connect, $sql);
        mysqli_stmt_bind_param($stmt, "s", $officeId);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if (password_verify($password, $row["password_hash"])) {
                $decryptedEmail = openssl_decrypt($row['email'], 'aes-256-cbc', $row['encryption_key'], 0, $row['encryption_key']);

               
                $fraud_data = [
                    'ct_src_dport_ltm' => 15,  
                    'ct_dst_sport_ltm' => 15,  
                    'sbytes' => 5000,  
                    'dbytes' => 5000, 
                    'spkts' => 50,  
                    'dpkts' => 50,  
                    'rate' => 1.5  
                ];

                $fraud_result = detectFraud($fraud_data);

                if ($fraud_result === 'fraud') {
                    echo '<script>alert("Fraud detected. Access denied.");</script>';
                    exit();
                } else {
                    $otp = generateOTP();
                    $_SESSION['decryptedEmail'] = $decryptedEmail;
                    $_SESSION['row'] = $row;
                    $_SESSION['otp'] = $otp;
                    $_SESSION['otp_expiry'] = time() + (4 * 60);

                    $mail = new PHPMailer();
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'dinshehas@gmail.com';
                    $mail->Password = 'hfad yknl tawp jeef';
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->Port = 587;

                    $mail->setFrom('dinshehas@gmail.com', 'Din');
                    if ($decryptedEmail && $row) {
                        $mail->addAddress($decryptedEmail, $row['full_name']);
                    } else {
                        echo 'Failed to send OTP. Email address not found.';
                        exit();
                    }

                    $mail->Subject = 'One Time Password (OTP) for Login';
                    $mail->Body = 'Your OTP is: ' . $otp;

                    if ($mail->send()) {
                        header("Location: otp_verification_reset.php");
                        file_put_contents('login_logs.txt', "[" . date("Y-m-d H:i:s") . "] Valid password entered for office ID: $officeId\n", FILE_APPEND);
                        exit();
                    } else {
                        echo 'Failed to send OTP. Please try again later.';
                        echo 'Error: ' . $mail->ErrorInfo;
                    }
                }
            } else {
                $_SESSION['login_attempts'][$officeId]['password']++;
                if ($_SESSION['login_attempts'][$officeId]['password'] >= 3) {
                    echo "Too many invalid password attempts. Account locked.";
                    file_put_contents('login_logs.txt', "[" . date("Y-m-d H:i:s") . "] Too many invalid password attempts. Account locked for office ID: $officeId\n", FILE_APPEND);
                    exit();
                }
                echo "Invalid password.";
                file_put_contents('login_logs.txt', "[" . date("Y-m-d H:i:s") . "] Invalid password for office ID: $officeId\n", FILE_APPEND);
            }
        } else {
            $_SESSION['login_attempts'][$officeId]['password']++;
            if ($_SESSION['login_attempts'][$officeId]['password'] >= 3) {
                echo "Too many invalid office ID attempts. Account locked.";
                file_put_contents('login_logs.txt', "[" . date("Y-m-d H:i:s") . "] Too many invalid office ID attempts. Account locked for office ID: $officeId\n", FILE_APPEND);
                exit();
            }
            echo "Invalid office ID.";
            file_put_contents('login_logs.txt', "[" . date("Y-m-d H:i:s") . "] Invalid office ID: $officeId\n", FILE_APPEND);
        }
    } elseif (isset($_POST['forgot_password'])) {
        $officeId = filter_input(INPUT_POST, 'officeId', FILTER_SANITIZE_STRING);

        $sql = "SELECT * FROM users WHERE office_id = ?";
        $stmt = mysqli_prepare($connect, $sql);
        mysqli_stmt_bind_param($stmt, "s", $officeId);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $decryptedEmail = openssl_decrypt($row['email'], 'aes-256-cbc', $row['encryption_key'], 0, $row['encryption_key']);
            $otp = generateOTP();
            $_SESSION['decryptedEmail'] = $decryptedEmail;
            $_SESSION['row'] = $row;
            $_SESSION['otp'] = $otp;
            $_SESSION['otp_expiry'] = time() + (4 * 60);

            $mail = new PHPMailer();
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'dinshehas@gmail.com';
            $mail->Password = 'hfad yknl tawp jeef';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            $mail->setFrom('dinshehas@gmail.com', 'Din');
            if ($decryptedEmail && $row) {
                $mail->addAddress($decryptedEmail, $row['full_name']);
            } else {
                echo 'Failed to send OTP. Email address not found.';
                exit();
            }

            $mail->Subject = 'One Time Password (OTP) for Password Reset';
            $mail->Body = 'Your OTP is: ' . $otp;

            if ($mail->send()) {
                header("Location: otp_verification.php?reset_password=true");
                exit();
            } else {
                echo 'Failed to send OTP. Please try again later.';
                echo 'Error: ' . $mail->ErrorInfo;
            }
        } else {
            echo "Invalid office ID.";
        }
    }
}

ob_end_flush();
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/stl.css">
    <style>
        body {
            background-color: #b6c4ff;
            font-family: Arial, sans-serif;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .card {
            width: 400px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .card-header {
            background-color: #434963;
            color: #fff;
            border-radius: 15px 15px 0 0;
            padding: 20px;
            text-align: center;
        }
        .card-body {
            padding: 20px;
        }
        .form-label {
            font-weight: bold;
        }
        .captcha-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .captcha-input {
            flex: 1;
            margin-left: 10px;
        }
        .btn-primary {
            display: block;
            width: 150px;
            margin: 20px auto 0;
        }
        .navbar {
            background-color: #343a40;
        }
        .navbar-brand {
            color: #ffffff;
        }
        .navbar-toggler-icon {
            color: #ffffff;
        }
        .nav-link {
            color: #ffffff !important;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-dark" data-bs-theme="dark">
    <div class="container-fluid">
        <a class="navbar-brand text-light">RockFORT</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav ms-auto">
                <a href="voterlogin.php" class="nav-link" style="background-color: #007bff; color: #ffffff; border-radius: 8px; padding: 8px 16px; text-decoration: none;">Go Back</a>
            </div>
        </div>
    </div>
</nav>
<div class="container">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Voter Login</h3>
        </div>
        <div class="card-body">
            <form id="loginForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                <div class="mb-3">
                    <input type="text" class="form-control" placeholder="Office ID" id="officeId" name="officeId" required>
                </div>
                <div class="mb-3">
                    <input type="password" class="form-control" placeholder="Password" id="password" name="password" required>
                </div>
                <div class="mb-3 captcha-container">
                    <img src="captcha.php" alt="CAPTCHA">
                    <input type="text" id="captcha" placeholder="Captcha" name="captcha" class="form-control captcha-input" required>
                </div>
                <button type="submit" class="btn btn-primary" style="width: 300px;">Login</button>

            </form>
            <form id="forgotPasswordForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                <button type="submit" name="forgot_password" style="color: darkgrey; text-decoration: underline; border: none; background: none; cursor: pointer;">Forgot Password?</button>
                <div class="mb-3">
                    <input type="text" class="form-control" id="officeId" placeholder="Office ID" name="officeId" required>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>
