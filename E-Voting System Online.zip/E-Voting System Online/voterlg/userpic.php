
<?php
session_start();


if (!isset($_SESSION['office_id'])) {
    header("Location: userpw.php");
    exit();
}

include("../api/connect.php");


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES['verificationPic'])) {
    $officeId = $_SESSION['office_id'];
    $uploadedPicTmpName = $_FILES['verificationPic']['tmp_name'];

  
    if (!is_uploaded_file($uploadedPicTmpName) || !exif_imagetype($uploadedPicTmpName)) {
        die("Error: Uploaded file is not a valid image.");
    }


    $uploadedPicContent = file_get_contents($uploadedPicTmpName);
    $uploadedPicHash = hash_file('sha256', $uploadedPicTmpName);

    
    $sql = "SELECT * FROM users WHERE office_id=?";
    $stmt = $connect->prepare($sql);
    $stmt->bind_param("s", $officeId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $storedPicHash = $row["verification_pic_hash"];

       
        if ($storedPicHash === $uploadedPicHash) {
            
            $encryptionKey = $row["encryption_key"];
            $storedEncryptedPic = $row["verification_pic"];

           
            $storedPic = openssl_decrypt($storedEncryptedPic, 'aes-256-cbc', $encryptionKey, 0, $encryptionKey);

            
            if (compareImages($storedPic, $uploadedPicContent)) {
            
                echo "Uploaded";
            } else {
                echo "Uploaded picture does not match the stored picture.";
            }
        } else {
            echo "Uploaded picture hash does not match the stored hash.";
        }
    } else {
        echo "Invalid office ID.";
    }
}



function compareImages($imageData1, $imageData2) {
  
    $image1 = imagecreatefromstring($imageData1);
    $image2 = imagecreatefromstring($imageData2);

   
    $width1 = imagesx($image1);
    $height1 = imagesy($image1);
    $width2 = imagesx($image2);
    $height2 = imagesy($image2);

    
    if ($width1 !== $width2 || $height1 !== $height2) {
        return false;
    }

   
    for ($x = 0; $x < $width1; $x++) {
        for ($y = 0; $y < $height1; $y++) {
           
            $pixelColor1 = imagecolorat($image1, $x, $y);
            $pixelColor2 = imagecolorat($image2, $x, $y);

           
            $red1 = ($pixelColor1 >> 16) & 0xFF;
            $green1 = ($pixelColor1 >> 8) & 0xFF;
            $blue1 = $pixelColor1 & 0xFF;

            $red2 = ($pixelColor2 >> 16) & 0xFF;
            $green2 = ($pixelColor2 >> 8) & 0xFF;
            $blue2 = $pixelColor2 & 0xFF;

            
            if ($red1 !== $red2 || $green1 !== $green2 || $blue1 !== $blue2) {
               
                imagedestroy($image1);
                imagedestroy($image2);
                return false;
            }
        }
    }

  
    imagedestroy($image1);
    imagedestroy($image2);
    return true;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Picture Upload</title>
</head>
<body>
    <h2>Upload Verification Picture</h2>
    <form id="uploadForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" enctype="multipart/form-data">
        <label for="verificationPic">Verification Picture:</label><br>
        <input type="file" id="verificationPic" name="verificationPic" accept="image/*" required><br>
        <button type="submit">Upload</button>
    </form>
</body>
</html>
