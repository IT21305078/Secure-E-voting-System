

<?php

if (!isset($_SERVER['HTTPS']) || $_SERVER['HTTPS'] !== 'on') {
    header('Location: https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
    exit();
}

if (session_status() === PHP_SESSION_NONE) {
   
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => $_SERVER['HTTP_HOST'],
        'secure' => true, 
        'httponly' => true,
        'samesite' => 'Strict'
    ]);
    session_start();
}

include("../api/connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['choice'])) {
    if ($_POST['choice'] == 'password') {
        header("Location: https://{$_SERVER['HTTP_HOST']}/E-Voting System Online/voterlg/userpw.php");
        exit();
    } elseif ($_POST['choice'] == 'fingerprint') {
        echo '
            <script>
                const officeId = prompt("Please enter your Office ID:");
                if (officeId !== null && officeId !== "") {
                    window.location = "https://localhost/E-Voting System Online/voterlg/voterfig.php?officeId=" + encodeURIComponent(officeId);
                } else {
                    alert("Office ID is required for fingerprint authentication.");
                    window.location = "https://' . $_SERVER['HTTP_HOST'] . '/voterlogin.php";
                }
            </script>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voter Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/stl.css">
    <style>
        body {
            background-color: #b6c4ff;
            font-family: Arial, sans-serif;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .card {
            width: 400px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .card-header {
            background-color: #434963;
            color: #fff;
            border-radius: 15px 15px 0 0;
            padding: 20px;
            text-align: center;
        }
        .card-body {
            padding: 20px;
        }
        .form-label {
            font-weight: bold;
        }
        .btn-primary {
            width: 100%;
        }
        .navbar {
            background-color: #343a40;
        }
        .navbar-brand {
            color: #ffffff;
        }
        .navbar-toggler-icon {
            color: #ffffff;
        }
        .nav-link {
            color: #ffffff !important;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-dark" data-bs-theme="dark">
    <div class="container-fluid">
        <a class="navbar-brand text-light">RockFORT</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav ms-auto">
                <a href="https://<?php echo $_SERVER['HTTP_HOST']; ?>/E-Voting System Online/index.html" class="nav-link" style="background-color: #007bff; color: #ffffff; border-radius: 8px; padding: 8px 16px; text-decoration: none;">Go Back</a>
            </div>
        </div>
    </div>
</nav>

<div class="container">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Voter Login</h3>
        </div>
        <div class="card-body">
            <div class="mb-3">
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <button type="submit" class="btn btn-primary" name="choice" value="password">Use Password</button>
                </form>
            </div>
            <div class="mb-3">
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <button type="submit" class="btn btn-primary" name="choice" value="fingerprint">Use Fingerprint</button>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>

