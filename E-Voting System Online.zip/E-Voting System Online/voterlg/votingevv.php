<?php

if (!isset($_SERVER['HTTPS']) || $_SERVER['HTTPS'] !== 'on') {
    header('Location: https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
    exit();
}

if (session_status() === PHP_SESSION_NONE) {
    
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => $_SERVER['HTTP_HOST'],
        'secure' => true, 
        'httponly' => true,
        'samesite' => 'Strict'
    ]);
    session_start();
}

if (!isset($_SESSION['office_id'])) {
    header("Location: voterlogin.php");
    exit();
}

include("../api/connect.php");

$userdata = null;
$decryptedEmail = '';
$decryptedPhone = '';

if (isset($_SESSION['office_id'])) {
    $officeId = $_SESSION['office_id'];
    $sql = "SELECT * FROM users WHERE office_id = ?";
    $stmt = mysqli_prepare($connect, $sql);
    mysqli_stmt_bind_param($stmt, "s", $officeId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if ($result->num_rows > 0) {
        $userdata = $result->fetch_assoc();

       
        $decryptedEmail = openssl_decrypt($userdata['email'], 'aes-256-cbc', $userdata['encryption_key'], 0, $userdata['encryption_key']);
        $decryptedPhone = openssl_decrypt($userdata['phone'], 'aes-256-cbc', $userdata['encryption_key'], 0, $userdata['encryption_key']);
    }
}

$groups = mysqli_query($connect, "SELECT * FROM candidate");
$groupdata = [];
while ($row = mysqli_fetch_assoc($groups)) {
    $groupdata[] = $row;
}

$check_user_status_query = mysqli_query($connect, "SELECT status FROM users WHERE office_id='$officeId'");
$user_status_row = mysqli_fetch_assoc($check_user_status_query);
$user_status = isset($user_status_row['status']) ? $user_status_row['status'] : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link type="text/css" href="../css/stl.css" rel="stylesheet">
    <link rel="icon" type="image/ico" href="favicon.ico">
    <title>E-Voting System</title>
    <style>
        .voter-details {
            background-color: rgba(248, 249, 250, 0.5);
            padding: 20px;
            border-radius: 10px;
        }
        .voter-details table td {
            padding: 5px;
        }
        .candidate-card {
            margin-top: 20px;
        }
        .candidate-card img {
            max-height: 150px;
            object-fit: cover;
            border-radius: 5px;
        }
        .candidate-card .card-body {
            text-align: center;
        }
        .candidate-card .btn {
            margin-top: 10px;
        }
    </style>
</head>
<body>   
    <nav class="navbar navbar-expand-lg bg-dark" data-bs-theme="dark">
        <div class="container-fluid">
            <a class="navbar-brand text-light">RockFORT</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <a href="../index.html" class="btn btn-primary">Log Out</a>
        </div>
    </nav>
    <h1 class="text-center mt-4">Welcome to Voting Page</h1>
    <div class="container form-body" style="background-color: rgba(248, 249, 250, 0.3);">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="voter-details">
                    <?php if (isset($userdata)): ?>
                        <h4 class="mb-3">Voter Details</h4>
                        <table class="table">
                            <tbody>
                                <tr>
                                    <td class="font-weight-bold">Name:</td>
                                    <td><?php echo htmlspecialchars($userdata['full_name']); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Phone number:</td>
                                    <td><?php echo htmlspecialchars($decryptedPhone); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Department:</td>
                                    <td><?php echo htmlspecialchars($userdata['department']); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Gender:</td>
                                    <td><?php echo htmlspecialchars($userdata['sex']); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Email:</td>
                                    <td><?php echo htmlspecialchars($decryptedEmail); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="row">
            <?php if (!empty($groupdata)): ?>
                <?php foreach ($groupdata as $candidate): ?>
                    <div class="col-md-3">
                        <div class="card candidate-card">
                            <img src="../uploads/<?php echo htmlspecialchars($candidate['photo']); ?>" class="card-img-top" alt="Candidate Image">
                            <div class="card-body">
                                <h5 class="card-title">Candidate: <?php echo htmlspecialchars($candidate['name']); ?></h5>
                                <?php if ($user_status == 1): ?>
                                    <button type="button" class="btn btn-primary" disabled>Voted</button>
                                <?php else: ?>
                                    <form action="votingr.php" method="POST" enctype="multipart/form-data">
                                        <input type="hidden" name="vid" value="<?php echo htmlspecialchars($officeId); ?>">
                                        <input type="hidden" name="gvotes" value="<?php echo htmlspecialchars($candidate['votes']); ?>">
                                        <input type="hidden" name="gname" value="<?php echo htmlspecialchars($candidate['name']); ?>">
                                        <button type="submit" class="btn btn-primary">Vote</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col">
                    <div class="alert alert-warning" role="alert">
                        No candidates available right now.
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
