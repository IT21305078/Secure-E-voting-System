import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import pickle


data = pd.read_csv('C:/xampp/htdocs/E-Voting System Online/UNSW_NB15_combined.csv')


data = data.dropna()


features = data[['ct_src_dport_ltm', 'ct_dst_sport_ltm', 'sbytes', 'dbytes', 'spkts', 'dpkts', 'rate']].apply(pd.to_numeric)


X_train, X_test = train_test_split(features, test_size=0.2, random_state=42)


scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)


model = IsolationForest(contamination=0.01, random_state=42)  
model.fit(X_train_scaled)


with open('C:/xampp/htdocs/E-Voting System Online/fraud_detection_model.pkl', 'wb') as model_file:
    pickle.dump(model, model_file)

with open('C:/xampp/htdocs/E-Voting System Online/scaler.pkl', 'wb') as scaler_file:
    pickle.dump(scaler, scaler_file)

print("Model and scaler saved successfully.")

