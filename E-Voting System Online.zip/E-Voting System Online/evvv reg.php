<?php
session_start();

include('api/connect.php');


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullName = $_POST['fullName'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $officeId = $_POST['officeId'];
    $sex = $_POST['sex'];
    $department = $_POST['department'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];
    $verificationPicTmpName = $_FILES['verificationPic']['tmp_name'];

    
    if ($password !== $confirmPassword) {
        die("Error: Passwords do not match");
    }

    
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    
    $encryptionKey = generateRandomString(16); 
    $encryptedEmail = openssl_encrypt($email, 'aes-256-cbc', $encryptionKey, 0, $encryptionKey);
    $encryptedPhone = openssl_encrypt($phone, 'aes-256-cbc', $encryptionKey, 0, $encryptionKey);

    
    $verificationPicContent = file_get_contents($verificationPicTmpName);
    $encryptedVerificationPic = openssl_encrypt($verificationPicContent, 'aes-256-cbc', $encryptionKey, 0, $encryptionKey);

   
    $verificationPicHash = hash('sha256', $verificationPicContent);

    
    $sql = "INSERT INTO users (full_name, email, phone, office_id, sex, department, password_hash, verification_pic, verification_pic_hash, encryption_key) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssssss", $fullName, $encryptedEmail, $encryptedPhone, $officeId, $sex, $department, $hashedPassword, $encryptedVerificationPic, $verificationPicHash, $encryptionKey);

  
    if ($stmt->execute() === TRUE) {
        echo "User registered successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}


function generateRandomString($length = 16) {
    return bin2hex(random_bytes($length / 2));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
</head>
<body>
    <h2>User Registration</h2>
    <form id="registrationForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" enctype="multipart/form-data">
        <label for="fullName">Full Name:</label><br>
        <input type="text" id="fullName" name="fullName" required><br>
        
        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email" required><br>
        
        <label for="phone">Phone Number:</label><br>
        <input type="tel" id="phone" name="phone" pattern="[0-9]{10}" required><br>
        
        <label for="officeId">Office ID:</label><br>
        <input type="text" id="officeId" name="officeId" maxlength="5" required><br>
        
        <label for="sex">Sex:</label><br>
        <select id="sex" name="sex" required>
            <option value="male">Male</option>
            <option value="female">Female</option>
        </select><br>
        
        <label for="department">Department:</label><br>
        <input type="text" id="department" name="department" required><br>
        
        <label for="password">Password:</label><br>
        <input type="password" id="password" name="password" required><br>
        
        <label for="confirmPassword">Confirm Password:</label><br>
        <input type="password" id="confirmPassword" name="confirmPassword" required><br>
        
        <label for="verificationPic">Verification Picture:</label><br>
        <input type="file" id="verificationPic" name="verificationPic" accept="image/*" required><br>
        
        <button type="submit">Register</button>
    </form>
</body>
</html>
