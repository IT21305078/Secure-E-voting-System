import pandas as pd


training_set = pd.read_parquet('C:/Users/Dell/Downloads/UNSW-NB15/UNSW_NB15_training-set.parquet')
testing_set = pd.read_parquet('C:/Users/Dell/Downloads/UNSW-NB15/UNSW_NB15_testing-set.parquet')


combined_df = pd.concat([training_set, testing_set], ignore_index=True)


combined_df.to_csv('C:/xampp/htdocs/E-Voting System Online/UNSW_NB15_combined.csv', index=False)


print(combined_df.head())
