
<?php
   
    include('connect.php');

    
    if (isset($_POST['submit'])){

        
        $reset = mysqli_query($connect,"UPDATE voter SET status = 0");

       
        $candidate_delete = mysqli_query($connect, "DELETE FROM candidate");

        $folder_path = "../uploads/";

        $folder = opendir($folder_path);

        while (($file = readdir($folder)) !== false) {
          
            if ($file == '.' || $file == '..') {
                continue;
            }

           
            if (is_dir($folder_path . $file)) {
                
                delete_folder($folder_path . $file);
            } else {
                
                unlink($folder_path . $file);
            }
        }

      
        closedir($folder);

       
        function delete_folder($folder_path) {
            
            $folder = opendir($folder_path);

           
            while (($file = readdir($folder)) !== false) {
                
                if ($file == '.' || $file == '..') {
                    continue;
                }

                
                if (is_dir($folder_path . $file)) {
                    
                    delete_folder($folder_path . $file);
                } else {
                    
                    unlink($folder_path . $file);
                }
            }

            
            closedir($folder);

            
            rmdir($folder_path);
        }

        
        echo '
            <script>
                alert("Ready to Vote");
                window.location = "../routes/reset_vote.php";
            </script>';
    }
?>
