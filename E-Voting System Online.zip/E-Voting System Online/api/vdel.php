<?php

if (!isset($_SERVER['HTTPS']) || $_SERVER['HTTPS'] !== 'on') {
    header('Location: https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
    exit();
}

if (session_status() === PHP_SESSION_NONE) {
    
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => $_SERVER['HTTP_HOST'],
        'secure' => true,
        'httponly' => true,
        'samesite' => 'Strict'
    ]);}
    session_start();
include("connect.php");

if (isset($_POST['delbtn'])){
    $voterid = $_POST['voterid'];
    

    $delete_query = mysqli_query($connect, "DELETE FROM users WHERE office_id='$voterid'");
    if($delete_query){
        echo '<script>
                    alert("Deleted voter successfully");
                    window.location = "../routes/voter_del.php";
                </script>';
            exit();
        }
    
    else{
        echo '<script>
                alert("");
                window.location = "../routes/voter_del.php";
            </script>';
    }
}
?>
