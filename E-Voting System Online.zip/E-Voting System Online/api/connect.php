<?php
    $connect = mysqli_connect("localhost", "root", "", "evvv") or die("connection failed!");
    if (!$connect) {
        die('Connection failed: ' . mysqli_connect_error());
    }
?>