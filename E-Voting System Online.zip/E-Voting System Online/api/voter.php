<?php
    include("connect.php");

    
    
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $fullName = $_POST['fullName'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $officeId = $_POST['officeId'];
        $sex = $_POST['sex'];
        $department = $_POST['department'];
        $password = $_POST['password'];
        $confirmPassword = $_POST['confirmPassword'];
        $verificationPicTmpName = $_FILES['verificationPic']['tmp_name'];
        $isotemplate = $_POST['txtIsoTemplate'];

        
        
        if ($password !== $confirmPassword) {
            die("Error: Passwords do not match");
        }

        
        
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        
        
        $encryptionKey = generateRandomString(16); 
        
        $encryptedEmail = openssl_encrypt($email, 'aes-256-cbc', $encryptionKey, 0, $encryptionKey);
        $encryptedPhone = openssl_encrypt($phone, 'aes-256-cbc', $encryptionKey, 0, $encryptionKey);

        
        
        $verificationPicContent = file_get_contents($verificationPicTmpName);
        $encryptedVerificationPic = openssl_encrypt($verificationPicContent, 'aes-256-cbc', $encryptionKey, 0, $encryptionKey);

        
        
        $verificationPicHash = hash('sha256', $verificationPicContent);

        
        
        $sql = "INSERT INTO users (full_name, email, phone, office_id, sex, department, password_hash, verification_pic, verification_pic_hash, encryption_key, isotemplate) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        

        $stmt = $connect->prepare($sql);
        $stmt->bind_param("sssssssssss", $fullName, $encryptedEmail, $encryptedPhone, $officeId, $sex, $department, $hashedPassword, $encryptedVerificationPic, $verificationPicHash, $encryptionKey, $isotemplate);

        
        
        if ($stmt->execute() === TRUE) {
            
            
            echo '<script>
            alert("Registration Sucessful");
            window.location = "../routes/voters.php";
        </script>';

        } else {
            echo "Error: " . $sql . "<br>" . $connect->error;
        }
    }

   
    function generateRandomString($length = 16) {
        return bin2hex(random_bytes($length / 2));
    }
?>
